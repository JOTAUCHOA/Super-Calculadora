window.addEventListener('load', start);

function start() {
    render();
}

function render() {
    window.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            var valueOne = document.querySelector('#primeroNumero').value;
            var valueTwo = document.querySelector('#segundoNumero').value;
              if((valueOne=='' || valueTwo=='') || (isNaN(valueOne) || isNaN(valueTwo))){
                clearValuesInputs();
                window.alert("Por favor, preencha os campos corretamente");
            }
            else  {
                valueTwo = parseInt(valueTwo);
                valueOne = parseInt(valueOne);
                calculator(valueOne, valueTwo);
            }
        }
    });
}



function clearValuesInputs(){
    document.querySelector('#primeroNumero').value = '';
    document.querySelector('#segundoNumero').value = '';
}

function calculator(valueOne, valueTwo) {
    for (var i = 1; i <= 12; i++) {
        var result = 0;
        switch (i) {
            case 1:
                //A+B
                result = valueOne + valueTwo;
                console.log("Soma: " + result);
                createInputElement(result, i);
                break;
            case 2:
                // A-B
                result = valueOne - valueTwo;
                console.log("Subtração 1: " + result);
                createInputElement(result, i);
                break;
            case 3:
                // B-A
                result = valueTwo - valueOne;
                createInputElement(result, i);
                console.log("Subtração 2: " + result);
                break;
            case 4:
                // A*B
                result = valueOne * valueTwo;
                createInputElement(result, i);
                console.log("Multiplicação : " + result);
                break;
            case 5:
                // A/B
                if (valueOne === 0) {
                    result = 'Divisão por 0 não é póssivel'
                    createInputElement(result, i);
                }
                else {
                    result = valueTwo / valueOne;
                    createInputElement(result, i);
                    console.log("Divisão 2: " + result);
                }
                break;
            case 6:
                // B/A
                result = valueOne / valueTwo;
                createInputElement(result.toFixed(2), i);
                console.log("Divisão 1: " + result)
                break;
            case 7:
                // A²
                result = Math.pow(valueOne, 2);
                createInputElement(result, i);
                console.log("Potencia  2: " + result);
                break;

            case 8:
                //B²
                result = Math.pow(valueTwo, 2);
                createInputElement(result, i);
                console.log("Potencia  1: " + result);
                break;
            case 9:
                result = Divider(valueOne);
                console.log(result);
                createInputElement(result, i);
                break;
            case 10:
                result = Divider(valueTwo);
                console.log(result);
                createInputElement(result, i);
                break;
            case 11:
                result = Fatorial(valueOne);
                console.log(result)
                createInputElement(result, i);
                break;
            case 12:
                result = Fatorial(valueTwo);
                console.log(result)
                createInputElement(result, i);
                break;
        }
    }
}
function createInputElement(valueResult, index) {
    function RenderResults(inputTitle) {
        if (isNaN(valueResult)) {
            valueResult = valueResult;
            document.querySelector(inputTitle).value = valueResult;
        }
        else {
            valueResult = Intl.NumberFormat('pt-BR').format(valueResult);
            document.querySelector(inputTitle).value = valueResult;
        }
    }
    switch (index) {
        case 1:
            RenderResults('#inputSum');
            break;
        case 2:
            RenderResults('#inputSubAB');
            break;
        case 3:
            RenderResults('#inputSubBA');
            break;
        case 4:
            RenderResults('#inputMulti');
            break;
        case 5:
            RenderResults('#inputDivAB');
            break;
        case 6:
            RenderResults('#inputDivBA');
            break;
        case 7:
            RenderResults('#inputPotenA');
            break;
        case 8:
            RenderResults('#inputPotenB');
            break;
        case 9:
            RenderResults('#inputDividerA');
            break;
        case 10:
            RenderResults('#inputDividerB');
            break;
        case 11:
            RenderResults('#inputFatA');
            break;
        case 12:
            RenderResults('#inputFatB');
            break;
        default:
            break;
    }
}
function Divider(value) {
    var divideValues = [];
    for (var i = 1; i <= value; i++) {
        if (value % i === 0) {
            divideValues.push(i)
        }
    }

    return divideValues.join(' , ');
}

function Fatorial(value) {
    var fatorialValues = 1;
    for (var i = value; i > 1; i--) {
        fatorialValues = fatorialValues * i;
        console.log(fatorialValues);
    }
    return fatorialValues;

}